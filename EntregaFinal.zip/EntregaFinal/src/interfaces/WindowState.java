package interfaces;

public interface WindowState {

	public void onReady();

}